#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include<stdlib.h>
#include <GL/glut.h>

typedef struct {
    int sizeX, sizeY;
    GLubyte *data;
} PPMImage;

PPMImage *the_image;

static PPMImage *LoadPPM(const char *filename)
{
    char tstring[1000],inchar;
    PPMImage *result;
    FILE *fp;
    int maxval;

    fp = fopen(filename, "rb");
    if (!fp)
    {
	fprintf(stderr, "Unable to open file `%s'\n", filename);
	exit(1);
    }
    fscanf(fp,"%s",tstring);
    fprintf(stderr,"scanned %s\n",tstring);
    if (strncmp(tstring,"P6",2)) //produces 0 (false) if equal
        { 
         fprintf(stderr,"can only work with P6 versions of ppm images\n");
         exit(-1);
          }
     /*Check for comment and swallow whole line */
     inchar=fgetc(fp);
     while (isspace(inchar))
       inchar=fgetc(fp);
     while (inchar=='#')
          {
           while ((inchar=fgetc(fp))!='\n')
             {
              fprintf(stderr,"%c",inchar);
             }
           inchar=fgetc(fp);
           } 
    ungetc(inchar,fp);
    result = malloc(sizeof(PPMImage));
    if (!result)
    {
	fprintf(stderr, "Unable to allocate memory\n");
	exit(1);
    }

    if (fscanf(fp, "%d %d", &result->sizeX, &result->sizeY) != 2)
    {
	fprintf(stderr, "Error loading image size rows cols %s\n", filename);
	exit(1);
    }
    fprintf(stderr," reading %d %d image\n",result->sizeX,result->sizeY);
    if (fscanf(fp, "%d", &maxval) != 1)
    {
	fprintf(stderr, "Error loading image looking for 255 %s\n", filename);
	exit(1);
    }

    while (fgetc(fp) != '\n')
	;

    result->data = malloc(3 * result->sizeX * result->sizeY);
    if (!result)
    {
	fprintf(stderr, "Unable to allocate memory\n");
	exit(1);
    }
#ifdef NORMAL_RASTER_ORDER
  for (i=0;i<result->sizeY;i++)  
    if (fread(result->data+3*(result->sizeY-i-1)*result->sizeX, 
			    3 * result->sizeX, 1, fp) != 1)
    {
	fprintf(stderr, "Error loading image - wrong number of bytes %s\n", filename);
	exit(1);
    }

#else
    if (fread(result->data, 3 * result->sizeX, result->sizeY, fp) != result->sizeY)
    {
	fprintf(stderr, "Error loading image - wrong number of bytes %s\n", filename);
	exit(1);
    }

#endif
    fclose(fp);
  
    return result;
}
