#define LADDER_LENGTH	1.5
#define LADDER_HEIGHT	0.3
#define FRONT_PLATE_LENGTH 5 // flat floor without ladder in the front of the room
#define BACK_PLATE_LENGTH 2.5 

#define TABLE1_LENGTH 2
#define TABLE1_WIDTH 1.2
#define TABLE1_HEIGHT 1.2

#define TABLE1_POS_X	5
#define TABLE1_POS_Y	3
#define TABLE1_POS_Z	0	


#define TABLET_POS_X 4
#define TABLET_POS_Y 0.1// 0.1 means place it on(very close to) the wall
#define TABLET_POS_Z 2.0 
//GLfloat room1[][3]={{-5,-5,-1.50},{5,-5,-1.5},{5,5,-1.5},{-5,5,-1.5}, \
	{-5,-5,4},{5,-5,4},{5,5,4},{-5,5,4}};

#define MOVIE_POS_X	4 
#define MOVIE_POS_Y	0.1
#define MOVIE_POS_Z	1.5

#define MOVIE_L 5
#define MOVIE_H 3

#define POSTER_L	1
#define POSTER_W	1
#define POSTER_X	0.1
#define POSTER_Y	3
#define POSTER_Z	1.5

typedef struct area
{
	GLfloat *pPosition;
	GLfloat *pLWH;
}area;

#define room area
#define door area
#define blockedArea area

GLfloat room1_pos[3]={5,-11,-1.49};
GLfloat room1_lwh[3]={10,10,5};

GLfloat room2_pos[3]={-10.01,-8,-1.49};
GLfloat room2_lwh[3]={15,20,5};

room room1={room1_pos,room1_lwh};
room room2={room2_pos,room2_lwh};

GLfloat door1_postion[3]={9.95,5,0}; // relative position in the room
GLfloat door1_lwh[3]={0.1,1.5,2.5};
GLfloat door2_postion[3]={-0.05,5,0}; // relative position in the room
GLfloat door2_lwh[3]={0.1,1.5,2.5};

const door  door1={door1_postion,door1_lwh};
const door  door2={door2_postion,door2_lwh};

const door* doors[]={&door1,&door2,NULL};


GLfloat table1_pos[3]={TABLE1_POS_X,TABLE1_POS_Y,TABLE1_POS_Z};
GLfloat table1_lwh[3]={TABLE1_LENGTH,TABLE1_WIDTH,TABLE1_HEIGHT};


const blockedArea mBlockArea1={table1_pos,table1_lwh };
const blockedArea* blocks[]={&mBlockArea1,NULL};


