clear

for i=1:1:100
    %imshow(mov(100).cdata,mov(100).colormap);
    s1=sprintf('%d', i);
    s=['steve' s1 '.ppm'];
    m=imread(s);
    imshow(m);
end
