
#include <GL/glut.h>
#include <stdlib.h>
typedef enum {
	person_view=1,
		bird_view
}viewer;

viewer m_view;

static float xtrans=0.0,ytrans=0.0,ztrans=0.0;

void init(void)
{
	GLfloat light_diffuse[]={1.0,1.0,1.0,1.0};
	GLfloat light_position[]={0.0,0.0,0.0,1.0};
	
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_FLAT);
	glEnable(GL_DEPTH_TEST);
	
	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);
	glEnable(GL_LIGHT0);
	
}
///////////////////////////////////////////////////////
// draw(model) the world, don't change with viewpoint
//
//
///////////////////////////////////////////////////////
void world_draw()
{

}



void drawSquare(int x,int y, int size)
{
	//glColor3ub(255,255,0);
	glBegin(GL_POLYGON);
	glVertex2f(x+size,y+size);
	glVertex2f(x-size,y+size);
	glVertex2f(x-size,y-size);
	glVertex2f(x+size,y-size);
	//glVertex2f(x-size,y-size);
	glEnd();
	glFlush();
}
///////////////////////////////////////////////////////
// display the world, change with viewpoint
//
//
///////////////////////////////////////////////////////
void display(void)
{
	
	GLfloat mat[]={1.0,1.0,0.0,1.0};
	GLfloat mat1[]={0.0,0.0,1.0,1.0};
	GLfloat boxv0[3],boxv1[3],boxv2[3],boxv3[3];
	glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	
	
	//glutWireSphere(2.0, 60, 60); /* draw sun */
	//glutWireOctahedron();
	//glutWireCube(3);
//	glRotatef ((GLfloat) year, 0.0, 1.0, 0.0);
//	glTranslatef (2.0, 0, 0); //radius
	glPopMatrix();
	
	/*
	glBegin(GL_POLYGON);
	glVertex3fv(0,0,0);
	glVertex3fv(0,2,0);
	glVertex3fv(2,2,0);
	glVertex3fv(2,0,0);
	glEnd();
*/
	glShadeModel(GL_FLAT);

    glBegin(GL_QUADS);
      //glColor4f(0.0, 0.0, 1.0);
	
	boxv0[0]=  -2;
	boxv0[1] = -2; 
	boxv0[2] = -1.5;

	boxv1[0] =  2;
    boxv1[1] = -2;
	boxv1[2] = -1.5;

	boxv2[0] = 2;
	boxv2[1] = 2;
    boxv2[2] = -1.5;

	boxv3[0] = -2;
	boxv3[1] = 2;
	boxv3[2] = -1.5;

      glVertex3fv(boxv0);
      glVertex3fv(boxv1);
      glVertex3fv(boxv2);
      glVertex3fv(boxv3);
	glEnd();
	//glClear(GL_DEPTH_BUFFER_BIT);
	//glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	//glColor3f (1.0, 0, 0);
	//glPushMatrix();
	//glutWireSphere(1.0, 20, 16); /* draw sun */
	//glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat);
	//glutSolidSphere(1.0,50,66); /* draw sun */
	//glutWireDodecahedron();
	//glRotatef ((GLfloat) year, 0.0, 1.0, 0.0);
	//glTranslatef (2.0, 0, 0); //radius
	//glColor3f (0, 1, 0);
	
	//glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat1);
	//glRotatef ((GLfloat) day, 0.0, 1.0, 0.0);
	//glutSolidSphere(0.2, 20, 10); /* draw smaller planet */
	//glPopMatrix(); 
	//glutSolidCone(0.08f,0.5f,10,2);
	
	
//	glTranslatef (0, -1, 1); //radius
//	glRotatef ((GLfloat) 1, 0.0, 1.0, 100.0);
//	drawSquare(0,0,2);
	glutSwapBuffers();
}

void reshape (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(90.0, (GLfloat) w/(GLfloat) h, 1, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//gluLookAt (0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
}
/* ARGSUSED1 */
void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
	case 'v':
		if(m_view==person_view)
		{
			m_view=bird_view;
		}else
		{
			m_view=person_view;
		}
		break;
		
	case 'f': //forward
		xtrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 'b': //backward
		xtrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 'l': //left
		ytrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 'r': //right
		ytrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 'u': //up
		ztrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 'd': //down
		ztrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
		glutPostRedisplay();
		break;
	case 27:
		exit(0);
		break;
	default:
		break;
	}
	
}
void idle()
{
	
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DEPTH|GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow (argv[0]);
	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);
	glutMainLoop();
	return 0;
}