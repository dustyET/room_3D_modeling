
#include <GL/glut.h>
#include <stdlib.h>
typedef enum {
	person_view=1,
		bird_view
}viewer;

viewer m_view;

static float xtrans=0.0,ytrans=0.0,ztrans=0.0;

void init(void)
{
	GLfloat light_diffuse[]={1.0,1.0,1.0,1.0};
	GLfloat light_position[]={0.0,0.0,0.0,1.0};
	
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_FLAT);
	glEnable(GL_DEPTH_TEST);
	
	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);
	glEnable(GL_LIGHT0);
	
}
///////////////////////////////////////////////////////
// draw(model) the world, don't change with viewpoint
//
//
///////////////////////////////////////////////////////
void world_draw()
{

}
///////////////////////////////////////////////////////
// display the world, change with viewpoint
//
//
///////////////////////////////////////////////////////
void display(void)
{
	
	GLfloat mat[]={1.0,1.0,0.0,1.0};
	GLfloat mat1[]={0.0,0.0,1.0,1.0};
	glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	
	
	//
	
	glutWireSphere(2.0, 60, 60); /* draw sun */
	//glutWireOctahedron();
//	glutWireCube(9);
//	glRotatef ((GLfloat) year, 0.0, 1.0, 0.0);
//	glTranslatef (2.0, 0, 0); //radius
	glPopMatrix();
	//glClear(GL_DEPTH_BUFFER_BIT);
	//glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	//glColor3f (1.0, 0, 0);
	//glPushMatrix();
	//glutWireSphere(1.0, 20, 16); /* draw sun */
	//glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat);
	//glutSolidSphere(1.0,50,66); /* draw sun */
	//glRotatef ((GLfloat) year, 0.0, 1.0, 0.0);
	//glTranslatef (2.0, 0, 0); //radius
	//glColor3f (0, 1, 0);
	
	//glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat1);
	//glRotatef ((GLfloat) day, 0.0, 1.0, 0.0);
	//glutSolidSphere(0.2, 20, 10); /* draw smaller planet */
	//glPopMatrix(); 
	glutSwapBuffers();
}
void reshape (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//gluLookAt (0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}
/* ARGSUSED1 */
void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
	case 'v':
		if(m_view==person_view)
		{
			m_view=bird_view;
		}else
		{
			m_view=person_view;
		}
		break;
		
	case 'r'://right //forward
		xtrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 'l'://left //backward
		xtrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 'f': //left
		ytrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 'b': //right
		ytrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 'u': //up
		ztrans+=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 'd': //down
		ztrans-=0.2;
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		gluLookAt (xtrans, ytrans, 5.0+ztrans, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		glutPostRedisplay();
		break;
	case 27:
		exit(0);
		break;
	default:
		break;
	}
	
}
void idle()
{
	
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DEPTH|GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow (argv[0]);
	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);
	glutMainLoop();
	return 0;
}