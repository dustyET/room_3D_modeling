#include <GL/glut.h>

#include <stdlib.h>
#include <math.h>
#include "loadppm.c"
#include "structure.h"
#include "ext_glut.h"
#define pi 3.14159
#define PERSON_HEIGHT 1.8
//#define LOOK_POS	(PERSON_HEIGHT-1.5)
#define LOOK_POS PERSON_HEIGHT
#define BIRD_HEIGHT 45
#define BIRD_X 30
#define BIRD_Y 0

#define CHAIR_TYPE_1 1
#define CHAIR_TYPE_2 2

typedef enum {
	person_view=1,
		bird_view
}viewer;

#define AREA_TYPE_BLOCK	1
#define AREA_TYPE_DOOR	2
#define AREA_TYPE_ROOM	3


GLint linearMap[]={GL_OBJECT_LINEAR};


float floor_height=-1.5;
//viewer m_view=1;
int window1,window2;
static float mAngle=180;
static float xtrans=16.0,ytrans=8.0,ztrans=0.0;
static float xtarget=0.0,ytarget=0.0,ztarget=0.0;
static float look_length=5,step_length=0.3,angle_step=1.0;//0.5; // could try to vary step size
static float cos_angle=0.0,sine_angle=0.0;

//static float m_position_x=0.0,m_position_y=0.0;
GLfloat no_mat[]={0,0,0,0.0};
int light_on=1;
GLfloat light_position[]={-10.0,1.0,20,1.0};
GLfloat light_position1[]={0.0,0.0,-1.0,.0};

GLfloat light_ambient[]={.4,.4,.4,.0};
GLfloat light_diffuse[]={.8,.8,.8,.0};
GLfloat light_specular[]={0.8,0.8,0.8,.0};
GLfloat light_emission[]={1.0,1.0,1.0,.0};

GLfloat mat_ambient_floor[]={0.2,0.2,0.2,1.0};
GLfloat mat_ambient_cel2[]={0.4,0.4,0.4,0.0};
GLfloat mat_ambient_cel1[]={0.6,0.6,0.6,0.0};
GLfloat mat_ambient_wall[]={0.35,0.35,0.35,1.0};

GLfloat mat_diffuse_floor[]={0.2,0.25,0.35,1.0};
GLfloat mat_diffuse_cel[]={0.5,0.5,0.5,0.0};
GLfloat mat_diffuse_wall1[]={0.8,0.8,0.8,1.0};
GLfloat mat_diffuse_wall2[]={0.6,0.6,0.6,1.0};

GLfloat mat_ambient_door[]={0.35,0.3,0.3,1.0};
GLfloat mat_diffuse_door[]={0.35,0.3,0.2,1.0};
GLfloat mat_specular_door[]={0.2,0.2,0.2,1.0};


GLfloat mat_specular[]={1.,1.,1.,0.0}; 
GLfloat mat_emission[]={1,1,1,0.0};

int x_old,y_old;
int isInRoomOld;
GLfloat room1_vetex[8][3];
GLfloat room2_vetex[8][3];


#define NUM_MOVIE_FRAME 20
#define NUM_MIP_MAP_POST	NUM_MOVIE_FRAME+1
#define NUM_MIP_MAP	NUM_MOVIE_FRAME+2
PPMImage *image1,*image2, *pmovie[NUM_MOVIE_FRAME];

static GLuint texName[NUM_MIP_MAP];
int movie_frame=1;

void init_texture_map(int window);
void loadImage();


void drawChair();
void drawMovie(float x,float y,float z);
void loadMovieFrame(int num);
void freeMovieFrame(int num_frame);

//////////////////////////////////////////////////////////////////////////////
// init module
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////
// initialize global variable
//
//////////////////////////////////////////
void init_globle_var()
{
	cos_angle=cos(mAngle/180.0*pi);
	sine_angle=sin(mAngle/180.0*pi);
}

void initRoomVetex(GLfloat pRoom[][3], GLfloat *pRoomLWH)//,GLfloat *pRoomPos)
{
	//GLfloat room1[][3]={{-5,-5,-1.50},{5,-5,-1.5},{5,5,-1.5},{-5,5,-1.5}, \
	{-5,-5,4},{5,-5,4},{5,5,4},{-5,5,4}};
	
	pRoom[0][0]=0;
	pRoom[0][1]=0;
	pRoom[0][2]=0;
	pRoom[1][0]=pRoomLWH[0];
	pRoom[1][1]=0;
	pRoom[1][2]=0;
	pRoom[2][0]=pRoomLWH[0];
	pRoom[2][1]=pRoomLWH[1];
	pRoom[2][2]=0;
	pRoom[3][0]=0;
	pRoom[3][1]=pRoomLWH[1];
	pRoom[3][2]=0;
	
	pRoom[4][0]=0;
	pRoom[4][1]=0;
	pRoom[4][2]=pRoomLWH[2];
	pRoom[5][0]=pRoomLWH[0];
	pRoom[5][1]=0;
	pRoom[5][2]=pRoomLWH[2];
	pRoom[6][0]=pRoomLWH[0];
	pRoom[6][1]=pRoomLWH[1];
	pRoom[6][2]=pRoomLWH[2];
	pRoom[7][0]=0;
	pRoom[7][1]=pRoomLWH[1];
	pRoom[7][2]=pRoomLWH[2];
	
}

void initRoomParameter()
{
	initRoomVetex(room1_vetex,room1_lwh);//,room1_pos);
	initRoomVetex(room2_vetex,room2_lwh);//,room2_pos);
}

void load_texture_file()
{
	int i;
	loadImage();
	for(i=1;i<NUM_MOVIE_FRAME;i++)
	{
		loadMovieFrame(i);
	}
}
void init()
{
	init_globle_var();
	initRoomParameter();	
	load_texture_file();
}

//////////////////////////////////////////////
// first mipmap is the tablet,
// 20 framefor the movie,
// the last one is the poster of the movie
// bind them into texture object for fast process
//////////////////////////////////////////////
void init_texture_map(int window)
{
	int i;
	
	glGenTextures(NUM_MIP_MAP, texName);

	glBindTexture(GL_TEXTURE_2D, texName[0]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image1->sizeX, image1->sizeY, GL_RGB,\
		GL_UNSIGNED_BYTE, image1->data);	

	glBindTexture(GL_TEXTURE_2D, texName[NUM_MIP_MAP_POST]);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image2->sizeX, image2->sizeY, GL_RGB,\
		GL_UNSIGNED_BYTE, image2->data);
			
	for(i=1;i<NUM_MOVIE_FRAME;i++)
	{
		glBindTexture(GL_TEXTURE_2D, texName[i]);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);
		gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pmovie[i]->sizeX, pmovie[i]->sizeY, GL_RGB,
			GL_UNSIGNED_BYTE, pmovie[i]->data);
		//freeMovieFrame();
	}
	
}
void free_texture_file()
{
	int i;
	free(image1);
	free(image2);

	for(i=1;i<NUM_MOVIE_FRAME;i++)
	{
		freeMovieFrame(i);
	}
}
//////////////////////////////////////////
// initialize window specific varible,
// such as lighting, etc.
//
//////////////////////////////////////////
void initWindow(int window)
{		
	//glClearColor (0.0, 0.0, 0.0, 0.0);
	glClearColor( 0.35f, 0.53f, 0.7f, .0f );
	//glShadeModel (GL_FLAT);
	//glShadeModel (GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT0,GL_AMBIENT,light_ambient);	
	glLightfv(GL_LIGHT0,GL_EMISSION,light_emission);
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);
	
	/*	glLightfv(GL_LIGHT1,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT1,GL_AMBIENT,no_mat);	
	glLightfv(GL_LIGHT1,GL_EMISSION,no_mat);
	glLightfv(GL_LIGHT1,GL_POSITION,light_position1);
	*/	
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	init_texture_map(window);
}

////////////////////////////////////////////////////////////
//  modeling module
////////////////////////////////////////////////////////////
void  drawSolidCube(float xLen, float yLen, float zLen)
{	
	//top
	glBegin(GL_QUADS);
	glNormal3d(0,0,1);
	glVertex3d(xLen,0,zLen);
	glVertex3d(xLen,yLen,zLen);
	glVertex3d(0,yLen,zLen);
	glVertex3d(0,0,zLen);
	
	//down
	glNormal3d(0,0,1);
	glVertex3d(xLen,0,0);
	glVertex3d(xLen,yLen,0);
	glVertex3d(0,yLen,0);
	glVertex3d(0,0,0);
	
	glNormal3d(1,0,0);
	glVertex3d(xLen,0,0);
	glVertex3d(xLen,yLen,0);
	glVertex3d(xLen,yLen,zLen);
	glVertex3d(xLen,0,zLen);
	
	glNormal3d(-1,0,0);
	glVertex3d(0,0,0);
	glVertex3d(0,yLen,0);
	glVertex3d(0,yLen,zLen);
	glVertex3d(0,0,zLen);
	
	glNormal3d(0,1,0);
	glVertex3d(0,   0,0);
	glVertex3d(xLen,0,0);
	glVertex3d(xLen,0,zLen);
	glVertex3d(0,   0,zLen);
	
	glNormal3d(0,-1,0);
	glVertex3d(0,   yLen,0);
	glVertex3d(xLen,yLen,0);
	glVertex3d(xLen,yLen,zLen);
	glVertex3d(0,   yLen,zLen);
	
	glEnd();
	
	
}

//////////////////////////////////////////


void m_Look_at()
{
	glutSetWindow(window1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//gluLookAt (xtrans, ytrans, 0, 0, look_length, ztarget, 0.0, 0.0, 1.0);	
	//gluLookAt (xtrans, ytrans, 0, xtrans+look_length*cos_angle, ytrans+look_length*sine_angle, ztarget, 0.0, 0.0, 1.0);
	
	gluLookAt (0, 0, PERSON_HEIGHT+floor_height, look_length,0, ztarget, 0.0, 0.0, 1.0);
	glRotatef(-mAngle,0,0,1);         // rotate camera-- rotate the world inversly, with axis xtrans,ytrans
	glTranslatef(-xtrans,-ytrans,0); // move camera -- move world in the inverse dirction
	
	glutPostWindowRedisplay(window1);
	
	glutSetWindow(window2);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt (BIRD_X, BIRD_Y, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
	
	glutPostWindowRedisplay(window2); 
}

///////////////////////////////////////////////////////
// draw table
//
//
///////////////////////////////////////////////////////
#define TABLE_L 2.0f
#define TABLE_W 1.0f
#define TABLE_H 1.2f
#define TABLE_POSITION_X 6  // relative postion in room1
#define TABLE_POSITION_Y 0.1 // close but not on the wall
#define TABLE_POSITION_Z 0//-1.5

#define LEG_HEIGTH TABLE_H
#define LEG_RADIUS 0.05
void drawTable(float pos_x,float pos_y, float pos_z)
{
	GLfloat table_ambient[]={0.8,0.8,0.8,1.0};
	GLfloat table_diffuse[]={0.8,0.8,0.8,1.0};
	GLfloat table_specular[]={0.7,0.7,0.7,1.0};
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,table_ambient);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,table_diffuse);
	
	glPushMatrix();
	glTranslatef(pos_x,pos_y,pos_z); 
	
	glPushMatrix();
	glTranslatef(0,0,TABLE_H); // the top suface of the table=TABLE_H
	drawSolidCube(TABLE_L,TABLE_W,0.05);
	glPopMatrix();
	
    // 4 legs of the table
	glPushMatrix();
	glTranslatef(TABLE_L/5.0,TABLE_W/5.0,0);
	glutSolidCylinder(LEG_RADIUS,LEG_HEIGTH,10,10);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(TABLE_L*0.8,TABLE_W/5.0,0);
	glutSolidCylinder(LEG_RADIUS,LEG_HEIGTH,10,10);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(TABLE_L*0.8,TABLE_W*0.8,0);
	glutSolidCylinder(LEG_RADIUS,LEG_HEIGTH,10,10);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(TABLE_L/5.0,TABLE_W*0.8,0);
	glutSolidCylinder(LEG_RADIUS,LEG_HEIGTH,10,10);
	glPopMatrix();
	
	glPopMatrix();
	
}


void drawTexture(float l,float h, int name)
{
	GLfloat texture[][3]={{0,0,0},{l,0,0},{l,0,h},{0,0,h}};
	glBindTexture(GL_TEXTURE_2D, texName[name]);
		
	/////////////////////
	glTexGeniv(GL_S,GL_TEXTURE_GEN_MODE,linearMap);
	glTexGeniv(GL_T,GL_TEXTURE_GEN_MODE,linearMap);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 1.0); 
	glVertex3fv(texture[0]);
	glTexCoord2f(0.0, 1.0);
	glVertex3fv(texture[1]);
	glTexCoord2f(0.0, 0.0); 
	glVertex3fv(texture[2]);
	glTexCoord2f(1.0, 0.0);
	glVertex3fv(texture[3]);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	/////////////////////////////////////
}
///////////////////////////////////////////////////////
// draw tablet ("sir alexander conference center")
//
//
///////////////////////////////////////////////////////
#define TABLET_L 2
#define TABLET_W 1

void drawTablet(float x,float y,float z)
{
	/*
	GLfloat tablet[][3]={{0,0,0},{TABLET_L,0,0},{TABLET_L,0,TABLET_W},{0,0,TABLET_W}};
	glBindTexture(GL_TEXTURE_2D, texName[0]);

	glPushMatrix(); //used if need to change its position
	glTranslatef(x,y,z);
	/////////////////////
	glTexGeniv(GL_S,GL_TEXTURE_GEN_MODE,linearMap);
	glTexGeniv(GL_T,GL_TEXTURE_GEN_MODE,linearMap);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 1.0); 
	glVertex3fv(tablet[0]);
	glTexCoord2f(0.0, 1.0);
	glVertex3fv(tablet[1]);
	glTexCoord2f(0.0, 0.0); 
	glVertex3fv(tablet[2]);
	glTexCoord2f(1.0, 0.0);
	glVertex3fv(tablet[3]);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();*/
	glPushMatrix();
	glTranslatef(x,y,z);
	drawTexture(TABLET_L,TABLET_W,0);
	glPopMatrix();
	/////////////////////////////////////
}


void drawPoster(float x,float y,float z, float angle)
{
		glPushMatrix();
		glTranslatef(x,y,z);
		glRotatef(angle,0,0,1);
		drawTexture(POSTER_L,POSTER_W,NUM_MIP_MAP_POST);
		glPopMatrix();
}
/////////////////////////////////////
// draw the doors
/////////////////////////////////////
void drawDoors(door** pDoor)//float xLen,float yLen,float zLen)
{
	int i;
	for(i=0;pDoor[i]!=NULL;i++)
	{
		glPushMatrix();
		glTranslatef(pDoor[i]->pPosition[0],pDoor[i]->pPosition[1],pDoor[i]->pPosition[2]);
		drawSolidCube(pDoor[i]->pLWH[0],pDoor[i]->pLWH[1],pDoor[i]->pLWH[2]);
		glPopMatrix();
	}
	
}
///////////////////////////////////////////////////////
// draw room
//
//
///////////////////////////////////////////////////////
void drawRoom1()
{		
	//int w=glutGetWindow();
	
	if(light_on)
	{
		glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);	
	}
	else
	{
		glLightfv(GL_LIGHT0,GL_DIFFUSE,no_mat);	
	}
	/////////////////////////////////////
	// the door plate
	/////////////////////////////////////
	drawTablet(TABLET_POS_X,TABLET_POS_Y,TABLET_POS_Z);
	//drawTexture(TABLET_POS_X,TABLET_POS_Y,TABLET_POS_Z,TABLET_L,TABLET_W,0);
	/////////////////////////////////////
	// the table
	/////////////////////////////////////
	drawTable(TABLE_POSITION_X,TABLE_POSITION_Y,TABLE_POSITION_Z);
	
	glPushMatrix();
	glTranslatef(5,1.2,0);
	glRotatef(180,0,0,1);
	drawChair(CHAIR_TYPE_1);	
	glPopMatrix();
	
	drawPoster(POSTER_X,POSTER_Y,POSTER_Z,-90);
	
	
	//drawTexture(1,1,1,POSTER_L,POSTER_W,NUM_MIP_MAP_POST);
	/////////////////////////////////////
	// the door
	/////////////////////////////////////
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_door);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_door);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,mat_specular_door);
	//glAlphaFunc ( GL_GREATER, 0.1 ) ;
	//glEnable(GL_ALPHA_TEST);
	//glRotatef(90,0,0,1);
	
	drawDoors(doors);//door1.pLWH [0],door1.pLWH [1],door1.pLWH [2]);
	//glDisable(GL_ALPHA_TEST);
	
	/////////////////////////////////////
	// the floor
	/////////////////////////////////////
	

	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);
	//floor
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);
	
	glNormal3d(0,0,1); 
	glVertex3fv(room1_vetex[0]);
	glVertex3fv(room1_vetex[1]);
	glVertex3fv(room1_vetex[2]);
	glVertex3fv(room1_vetex[3]);
	glEnd();
	
	//if(w==window1)
	{
		//celling
		glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_cel);
		glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_cel1);
		glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);
		
		
		if(light_on)
		{
			
			//glMaterialfv(GL_BACK,GL_EMISSION,mat_emission);
			glMaterialfv(GL_FRONT,GL_EMISSION,no_mat);
			
		}
		else
		{
			glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
		}
		glBegin(GL_QUADS);		
		glNormal3d(0,0,-1);  // face upward, otherwise it is dark in the bird's view even when light on
		glVertex3fv(room1_vetex[4]);
		glVertex3fv(room1_vetex[5]);
		glVertex3fv(room1_vetex[6]);
		glVertex3fv(room1_vetex[7]);
		glEnd();
	}
	//walls	
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_wall1);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_wall);
	glBegin(GL_QUADS);
	glNormal3d(0,1,0); 
	//glTexCoord2f(0.0, 0.0); 
	glVertex3fv(room1_vetex[0]);
	//glTexCoord2f(0.0, 1.0); 
	glVertex3fv(room1_vetex[4]);
	//glTexCoord2f(1.0, 1.0); 
	glVertex3fv(room1_vetex[5]);
	//glTexCoord2f(1.0, 0.0); 
	glVertex3fv(room1_vetex[1]);
	
	glNormal3d(0,-1,0); 
	//glTexCoord2f(0.0, 0.0); 
	glVertex3fv(room1_vetex[2]);
	//glTexCoord2f(0.0, 10.0);
	glVertex3fv(room1_vetex[6]);
	//glTexCoord2f(10.0, 10.0);
	glVertex3fv(room1_vetex[7]);
	//glTexCoord2f(10.0, 0.0);
	glVertex3fv(room1_vetex[3]);
	
	glNormal3d(1,0,0); 
	glVertex3fv(room1_vetex[2]);
	glVertex3fv(room1_vetex[6]);
	glVertex3fv(room1_vetex[5]);
	glVertex3fv(room1_vetex[1]);
	
	glNormal3d(-1,0,0); 
	glVertex3fv(room1_vetex[0]);
	glVertex3fv(room1_vetex[4]);
	glVertex3fv(room1_vetex[7]);
	glVertex3fv(room1_vetex[3]);
	
	glEnd();
	//glDisable(GL_TEXTURE_2D);
}
/*
#define LADDER_LENGTH	1.5
#define LADDER_HEIGHT	0.3
#define FRONT_PLATE_LENGTH 5 // flat floor with out ladder in the front of the room
#define BACK_PLATE_LENGTH 2.5 */
void drawLadderFloor()
{
	float i;
	float room_length=room2.pLWH[1];
	float room_width=room2.pLWH[0];
	//glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);
	glPushMatrix();
	glTranslatef(0.05,FRONT_PLATE_LENGTH,0);
	for(i=FRONT_PLATE_LENGTH;i<room_length-BACK_PLATE_LENGTH;i+=LADDER_LENGTH)
	{
		drawSolidCube(room_width-0.1,room_length-i-0.1,LADDER_HEIGHT);
		glTranslatef(0,LADDER_LENGTH,LADDER_HEIGHT);
	}
	
	glPopMatrix();
	
}


GLfloat mat_diffuse_table1[]={0.3,0.25,0.2,1.0};
GLfloat mat_ambient_table1[]={0.3,0.3,0.3,1.0};
GLfloat mat_specular_table[]={0.1,0.1,0.1,1.0};

void drawTable1()
{
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_table1);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_table1);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,mat_specular_table);
	
	
	glPushMatrix();
	glTranslatef(TABLE1_POS_X,TABLE1_POS_Y,TABLE1_POS_Z);
	drawSolidCube(TABLE1_LENGTH,TABLE1_WIDTH,TABLE1_HEIGHT);
	glPopMatrix();
}

#define CHAIR_WIDTH 0.8
#define CHAIR_LENGTH 0.8
#define CHAIR_HEIGHT 0.6
#define CHAIR_MARGIN 0.1
#define CHAIR_LEG_RADIUS 0.02
#define CHAIR_LEG_HEIGHT CHAIR_HEIGHT
#define CHAIR_BACK_HEIGHT 0.5


GLfloat mat_diffuse_chair[]={0.3,0.25,0.2,1.0};
GLfloat mat_ambient_chair[]={0.3,0.3,0.3,1.0};
GLfloat mat_specular_chair[]={0.1,0.1,0.1,1.0};
void drawChair(int type)
{	
	float leg_length=CHAIR_LEG_HEIGHT;
	if(type==CHAIR_TYPE_2) leg_length-=0.2;
	glPushMatrix();
	glTranslatef(0,0,leg_length);
	drawSolidCube(CHAIR_LENGTH-CHAIR_MARGIN,CHAIR_WIDTH-CHAIR_MARGIN,0.1);	
	//glPopMatrix();
	//glPushMatrix();
	glTranslatef(0,CHAIR_LENGTH-CHAIR_MARGIN,0);
	drawSolidCube(CHAIR_WIDTH-CHAIR_MARGIN,0.05,CHAIR_BACK_HEIGHT);
	glPopMatrix();
	
	glPushMatrix();
	glutSolidCylinder(CHAIR_LEG_RADIUS,leg_length,10,10);
	glTranslatef(CHAIR_WIDTH-CHAIR_MARGIN,0,0);
	glutSolidCylinder(CHAIR_LEG_RADIUS,leg_length,10,10);
	glPopMatrix();
	
	if(type==CHAIR_TYPE_1)
	{
		glPushMatrix();
		glTranslatef(0,CHAIR_LENGTH-CHAIR_MARGIN,0);
		
		glutSolidCylinder(CHAIR_LEG_RADIUS,leg_length,10,10);
		glTranslatef(CHAIR_WIDTH-CHAIR_MARGIN,0,0);
		glutSolidCylinder(CHAIR_LEG_RADIUS,leg_length,10,10);
		glPopMatrix();
	}
}

#define CHAIR_LINE_SPACE 2
void drawChairs()
{
	float i,j;
	float room_length=room2.pLWH[1];
	float room_width=room2.pLWH[0];
	//glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_chair);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_chair);
	glPushMatrix();
	glTranslatef(CHAIR_LINE_SPACE,FRONT_PLATE_LENGTH+0.5,LADDER_HEIGHT);
	for(i=FRONT_PLATE_LENGTH;i<room_length-BACK_PLATE_LENGTH;i+=LADDER_LENGTH)
	{
		float chair_space=CHAIR_WIDTH;
		
		glPushMatrix();
		for(j=CHAIR_LINE_SPACE;j<room_width-CHAIR_LINE_SPACE;j+=chair_space)
		{
			drawChair(CHAIR_TYPE_2);
			glTranslatef(chair_space,0,0);
		}
		glPopMatrix();
		glTranslatef(0,LADDER_LENGTH,LADDER_HEIGHT);
	}
	
	glPopMatrix();
	
}
void drawRoom2()
{	
	
	//int w=glutGetWindow();
	
	if(light_on)
	{
		glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
	}
	else
	{
		glLightfv(GL_LIGHT0,GL_DIFFUSE,no_mat);
	}
	///////////////////////
	drawLadderFloor();
	///////////////////////
	drawTable1();
	///////////////////////
	drawChairs();
	///////////////////////
	drawMovie(MOVIE_POS_X,MOVIE_POS_Y,MOVIE_POS_Z);
	//drawTexture(MOVIE_POS_X,MOVIE_POS_Y,MOVIE_POS_Z,MOVIE_L,MOVIE_H,movie_frame);
	
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);
	//floor
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
	
	glNormal3d(0,0,1); 
	glVertex3fv(room2_vetex[0]);
	glVertex3fv(room2_vetex[1]);
	glVertex3fv(room2_vetex[2]);
	glVertex3fv(room2_vetex[3]);
	glEnd();
	//if(w==window1)
	{
		//celling
		glBegin(GL_QUADS);
		glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_cel);
		glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_cel2);
		if(light_on)
		{
			
			//glMaterialfv(GL_BACK,GL_EMISSION,mat_emission);
			glMaterialfv(GL_FRONT,GL_EMISSION,no_mat);
			
		}
		else
		{
			glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
		}
		glNormal3d(0,0,1); 
		glVertex3fv(room2_vetex[4]);
		glVertex3fv(room2_vetex[5]);
		glVertex3fv(room2_vetex[6]);
		glVertex3fv(room2_vetex[7]);
		glEnd();
	}
	//walls	
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_wall2);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_wall);
	
	glNormal3d(0,1,0); 
	glVertex3fv(room2_vetex[0]);
	glVertex3fv(room2_vetex[4]);
	glVertex3fv(room2_vetex[5]);
	glVertex3fv(room2_vetex[1]);
	
	glNormal3d(0,-1,0); 
	glVertex3fv(room2_vetex[2]);
	glVertex3fv(room2_vetex[6]);
	glVertex3fv(room2_vetex[7]);
	glVertex3fv(room2_vetex[3]);
	
	glNormal3d(1,0,0); 
	glVertex3fv(room2_vetex[2]);
	glVertex3fv(room2_vetex[6]);
	glVertex3fv(room2_vetex[5]);
	glVertex3fv(room2_vetex[1]);
	
	glNormal3d(-1,0,0); 
	glVertex3fv(room2_vetex[0]);
	glVertex3fv(room2_vetex[4]);
	glVertex3fv(room2_vetex[7]);
	glVertex3fv(room2_vetex[3]);
	
	glEnd();

}

void drawGround()
{
	GLfloat gnd[][3]={{-20,-20,-1.51},{20,-20,-1.51},{20,20,-1.51},{-20,20,-1.51}};
	
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);
	
	glBegin(GL_QUADS);
	glNormal3d(0,0,1); 
	glVertex3fv(gnd[0]);
	glVertex3fv(gnd[1]);
	glVertex3fv(gnd[2]);
	glVertex3fv(gnd[3]);
	glEnd();
}


/////////////////////////////////////////////////////
// draw a 3-D person
/////////////////////////////////////////////////////
#define PERSON_LEG_RADIUS 0.1	
#define PERSON_LEG_LENGTH 1
#define PERSON_ARM_RADIUS 0.1	
#define PERSON_ARM_LENGTH 1
#define PERSON_RADIUS 0.2
#define PERSON_LENGTH 1
void drawPerson()
{	
	
	GLfloat mat_ambient_person[]={0.5,0.2,0.2,1.0};
	GLfloat mat_diffuse_person[]={0.5,0.25,0.35,1.0};
	//GLfloat mat_specular[]={1.,1.,1.,1.0}; 
	//GLfloat mat_emission[]={1,1,1,1.0};
	
	int i;
	int w=glutGetWindow();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_person);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_person);
	
	if(w==window1)
	{
		glutSetWindow(window2);
	}
	//////////////////////////////////
	//  debug version
	//////////////////////////////////	  
	
	glMatrixMode(GL_MODELVIEW);	
	
	glPushMatrix();
	//glLoadIdentity();
	//gluLookAt (BIRD_X, BIRD_Y, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
	glTranslatef(xtrans,ytrans,floor_height+PERSON_HEIGHT/2+0.1); // 0.1 for the margin, so that the person walks a little higher than the floor
	
	//	glutWireCone(1,1.5,20,20); //seems glut lib function has changed the lighting effect
	/////////////////////////////////////////////
	//  maybe I should draw a 3D person here
	/////////////////////////////////////////////
	glRotatef(mAngle,0,0,1); // rotate the direction of the person face to
	// to add code here...
	
	
	glPushMatrix();
	glutSolidCylinder(PERSON_RADIUS,PERSON_LENGTH,10,10);//body
	glTranslatef(0,0,0.4);
	glutSolidSphere(0.4,10,10); // 
	
	//////////////////////////////
	//arms
	glPushMatrix();
	glRotatef(120,1,0,0);
	glutSolidCylinder(PERSON_ARM_RADIUS,PERSON_ARM_LENGTH,10,10);
	glRotatef(120,1,0,0);
	glutSolidCylinder(PERSON_ARM_RADIUS,PERSON_ARM_LENGTH,10,10);
	glPopMatrix();
	//////////////////////////////
	//head
	glTranslatef(0,0,0.6);
	glutSolidSphere(0.3,10,10);
	glPopMatrix();
	//leg
	glPushMatrix();
	glRotatef(160,1,0,0);
	glutSolidCylinder(PERSON_LEG_RADIUS,PERSON_LEG_LENGTH,10,10);
	glRotatef(40,1,0,0);
	glutSolidCylinder(PERSON_LEG_RADIUS,PERSON_LEG_LENGTH,10,10);
	glPopMatrix();
	
	/////////////////////////////////////////////
	// the triangle to indicate the face of the person
	/////////////////////////////////////////////
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,mat_emission);
	glTranslatef(0,0,5);
	{
		GLfloat person[][3]={{0,0,-1.4},{0,0,-1.4},{0,0,-1.4}};//,{0,0,-1.5},{0,0,-1.5},{0,0,-1.5},{0,0,-1.5}};
		i=1;
		person[0][0]=-0.5;
		person[1][0]=0.5;
		person[2][0]=-0.5;
		//person[3][0]=0;
		
		person[0][1]=i;
		person[1][1]=0;
		person[2][1]=-i;
		//person[3][1]=-i;
		
		//glBegin(GL_QUADS);
		glBegin(GL_LINE_LOOP);
		glVertex3fv(person[0]);
		glVertex3fv(person[1]);
		glVertex3fv(person[2]);
		//glVertex3fv(person[2]);
		glEnd();
	}
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
	glPopMatrix();
	if(w==window1)
	{		
		glutSetWindow(window1);
	}
	//glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
}
///////////////////////////////////////////////////////
// display the world, change with viewpoint
//
//
///////////////////////////////////////////////////////
void display(void)
{	
	GLfloat mat_ambient[]={0.2,0.2,0.2,1.0};
	GLfloat mat_diffuse[]={0.5,0.5,0.5,1.0};
	GLfloat mat_specular[]={1.,1.,1.,1.0};
	GLfloat mat_emission[]={1,1,1,1.0};
	
	glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	glShadeModel(GL_SMOOTH);//GL_FLAT);
    
	
	
	glPushMatrix();
	glTranslatef(room1_pos[0],room1_pos[1],room1_pos[2]);
	drawRoom1();
	glPopMatrix();
	
	glPushMatrix();
	glTranslatef(room2_pos[0],room2_pos[1],room2_pos[2]);
	drawRoom2();
	glPopMatrix();
	drawGround();
	
	/////////display the light position for debug//////////
	/*glPushMatrix();
	glTranslatef(light_position[0],light_position[1],light_position[2]);
	glutSolidSphere(5,10,10);//light_position)//; debug
	glPopMatrix();*/
	///////////////////////////////////////////////////////
	drawPerson();
	
	glutSwapBuffers();
	
}


void reshape (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1, 70.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	//gluLookAt (xtrans+3, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
	//gluLookAt (xtrans, ytrans, 0, xtarget, ytarget, ztarget, 0.0, 0.0, 1.0);
	gluLookAt (xtrans, ytrans, PERSON_HEIGHT+floor_height, xtrans+look_length*cos_angle, ytrans+look_length*sine_angle, ztarget, 0.0, 0.0, 1.0);
	glDisable(GL_ALPHA_TEST);
	
}

void reshape1 (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(45.0, (GLfloat) w/(GLfloat) h, 1, 70.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt (BIRD_X, BIRD_Y, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
	glAlphaFunc ( GL_GREATER, 0.1 ) ;
	glEnable(GL_ALPHA_TEST);
}
////////////////////////////////////////////////////////////////////////////////////////
// movement control module:
////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////
// function:decide if the person is in an area
/////////////////////////////////////////////////
int isInArea(area mArea,int margin,room mRoom, int testType)
{
	int isIn=1;	
	GLfloat x=mArea.pPosition[0]+mRoom.pPosition[0];
	GLfloat y=mArea.pPosition[1]+mRoom.pPosition[1];	
	GLfloat xMin=x;
	GLfloat xMax=x+mArea.pLWH[0];
	GLfloat yMin=y;
	GLfloat yMax=y+mArea.pLWH[1];
	switch(testType)
	{
	case AREA_TYPE_BLOCK:// table,etc		
		xMin-=margin;
		xMax+=margin;
		yMin-=margin;
		yMax+=margin;
		break;
	case AREA_TYPE_DOOR: //door
		
		if(mArea.pLWH[0]<mArea.pLWH[1])
		{
			xMin-=margin;
			xMax+=margin;
		}
		else{
			yMin-=margin;
			yMax+=margin;
		} 
		break;
	case AREA_TYPE_ROOM:
		{
			float margin1=margin;
			if(isInRoomOld!=0)  margin1=-margin;
			
			xMin-=mRoom.pPosition[0];
			yMin-=mRoom.pPosition[1];
			xMax-=mRoom.pPosition[0];
			yMax-=mRoom.pPosition[1];
			xMin-=margin1;
			xMax+=margin1;
			yMin-=margin1;
			yMax+=margin1;
		}
		break;
	default:
		break;
	}
	if((xtrans>xMin && xtrans<xMax)&&(ytrans>yMin && ytrans<yMax))
	{
		isIn=1;
	}
	else
	{
		isIn=0;
	}
	return isIn;
}

/////////////////////////////////////////////////
// function:decide if the person is in the room
/////////////////////////////////////////////////

#define ROOM_MARGIN 0.8
int isInRoom(room mRoom)
{
	
/*	int isIn=1;
	GLfloat xMin=mRoom.pPosition[0];//-MARGIN;
	GLfloat xMax=mRoom.pPosition[0]+mRoom.pLWH[0];//+MARGIN;
	GLfloat yMin=mRoom.pPosition[1];//-MARGIN;
	GLfloat yMax=mRoom.pPosition[1]+mRoom.pLWH[1];//+MARGIN;
	
	if((xtrans>xMin && xtrans<xMax)&&(ytrans>yMin && ytrans<yMax))
	{
		isIn=1;
	}
	else
	{
		isIn=0;
	}
	return isIn; */
	isInArea(mRoom,ROOM_MARGIN,mRoom,AREA_TYPE_ROOM);
}


/////////////////////////////////////////////////
// function:decide if the person is working through the door
/////////////////////////////////////////////////
#define DOOR_MARGIN 2
int isInDoor(door mDoor)
{
	int isIn=isInArea(mDoor,DOOR_MARGIN,room1,AREA_TYPE_DOOR);
	return isIn;
}

int isThroughDoors(door *pdoor[])
{
	int i;
	int isThroughDoors=0;
	for(i=0;pdoor[i]!=NULL;i++)
	{
		door *pTemp=pdoor[i];
		if( isInDoor(*pTemp))
		{
			isThroughDoors=1;
		}
	}
	return isThroughDoors;
}

float getFloorHeight()
{
	int n;
	float z_pos_in_room2;
	float y_pos_room2=ytrans-room2.pPosition[1];
	if(isInRoom(room2))
	{		
		if(y_pos_room2<FRONT_PLATE_LENGTH) 
		{
			n=0;
		}
		else
		{
			n=1+(y_pos_room2-FRONT_PLATE_LENGTH)/LADDER_LENGTH;
		}
		
		
		z_pos_in_room2=n*LADDER_HEIGHT;//+(-1.5);
	}
	else
	{
		z_pos_in_room2=0;//-1.5;
	}
	z_pos_in_room2-=1.5;
	return z_pos_in_room2;
}

/* ARGSUSED1 */
void preMoveControl(int *inRoom1, int *inRoom2, float *xTranOld,float *yTranOld)
{
	*inRoom1=isInRoom(room1);
	*inRoom2=isInRoom(room2);
	*xTranOld=xtrans;
	*yTranOld=ytrans;
	isInRoomOld=(*inRoom1+*inRoom2);
}

#define BLOCK_MARGIN 0.8
int isInBlock(blockedArea mArea)
{
	return isInArea(mArea,BLOCK_MARGIN,room2,AREA_TYPE_BLOCK);
}
int isInBlockedAreas(blockedArea *pblocks[])
{
	int i;
	int isIn=0;
	for(i=0;pblocks[i]!=NULL;i++)
	{
		blockedArea *pTemp=pblocks[i];
		if(isInBlock(*pTemp))
		{
			isIn=1;
		}
	}	
	return(isIn);
}
void postMoveControl(int inRoom1, int inRoom2,float xTranOld,float yTranOld)
{
	int inRoomNew1=isInRoom(room1);
	int inRoomNew2=isInRoom(room2);
	
	if((inRoomNew1!=inRoom1 || inRoomNew2!=inRoom2 ))
	{
		if(!isThroughDoors(doors))
		{

			xtrans=xTranOld;
			ytrans=yTranOld;
		}
	}
	if(isInBlockedAreas(blocks))
	{
		xtrans=xTranOld;
		ytrans=yTranOld;
	}
	m_Look_at();
	floor_height=getFloorHeight();
}
void keyboard (unsigned char key, int x, int y)
{	
	int inRoom1,inRoom2;//,inRoomNew;
	float xTranOld,yTranOld;
	preMoveControl(&inRoom1, &inRoom2, &xTranOld, &yTranOld);
	
	switch (key) {
	case 'o':
		light_on=1;
		//m_Look_at();
		break;
	case 'O':
		light_on=0;
		//m_Look_at();		
		break;
		
	case 'f': //forward
		//xtrans+=0.2;
		
		//preMoveControl();
		xtrans+=step_length*cos_angle;
		ytrans+=step_length*sine_angle;
		
		//postMoveControl();
		//m_Look_at();
		break;
	case 'b': //backward
		xtrans-=step_length*cos_angle;
		ytrans-=step_length*sine_angle;
		//m_Look_at();
		break;
	case 'l': //left
		xtrans-=step_length*sine_angle;
		ytrans+=step_length*cos_angle;
		//m_Look_at();
		break;
	case 'r': //right
		xtrans+=step_length*sine_angle;
		ytrans-=step_length*cos_angle;
		//m_Look_at();
		break;
	case 'u': //up
		ztrans+=0.2;
		//m_Look_at();
		break;
	case 'd': //down
		ztrans-=0.2;
		//m_Look_at();
		break;
		
		//////////////////////////////////////////////
		// try to add angle control
		/*		case 'F': //forward
		xtarget+=step_szie;//0.2;
		m_Look_at();
		break;
		case 'B': //backward
		xtarget-=step_size;//0.2;
		m_Look_at();
		break;
		*/
	case 'L': //left
		//ytarget+=0.2;
		mAngle+=angle_step;//0.2;
		//m_Look_at();
		break;
	case 'R': //right
		mAngle-=angle_step;//0.2;
		//m_Look_at();
		break;
	case 'U': //up
		ztarget+=0.2;
		//m_Look_at();
		break;
	case 'D': //down
		ztarget-=0.2;
		//m_Look_at();
		break;
		//////////////////////////////////////////////
		
	case 27:
		exit(0);
		break;
	default:
		break;
	}
	
	if(mAngle>=360) mAngle=mAngle-360;
	if(mAngle<0) mAngle+=360;
	cos_angle=cos(mAngle/180.0*pi); // the paraameter should be in arc, not degree
	sine_angle=sin(mAngle/180.0*pi);
	postMoveControl(inRoom1, inRoom2, xTranOld, yTranOld);
}

void mouse(int btn, int state, int x, int y)
{
	
	/* mouse callback, selects an axis about which to rotate */
	int dx,dy;
	cos_angle=cos(mAngle/180.0*pi);
	sine_angle=sin(mAngle/180.0*pi);
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		
		x_old=x;
		y_old=y;
	}
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		dx=x-x_old;
		dy=y-y_old;
		
		//debug only
		//light_position[0]+=dx/20;
		//light_position[1]+=(y-y_old)/20;
		//glLightfv(GL_LIGHT0,GL_POSITION,light_position);
		
		ytrans+=dx/100.0;
		xtrans+=dy/100.0;
		m_Look_at();
		
	}
	
	//if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) axis = 1;
	//if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) axis = 2;
	
}
////////////////////////////////////////////////////
// image handel for texture mapping
////////////////////////////////////////////////////
void idle()
{
	/*static int i=1;
	if(isInRoom(room2))
	{
		showMovieFrame(i);
		if(i++>=99) i=1;
		glutPostWindowRedisplay(window1);
	}*/
	if(isInRoom(room2))
	{
		movie_frame++;
		if(movie_frame>=NUM_MOVIE_FRAME) movie_frame=1;		
		glutPostWindowRedisplay(window1);
	}
}
void loadImage()
{
	image1=LoadPPM("ppm/tablet.ppm");
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	image2=LoadPPM("ppm/movie/post.ppm");
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
}
void loadMovieFrame(int num)
{
	char name[30];
	sprintf(name ,"ppm/movie/steve%d.ppm",num);
	pmovie[num]=LoadPPM(name);
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
}
void freeMovieFrame(int num_frame)
{
	if(pmovie[num_frame]!=NULL) free(pmovie[num_frame]);
}
/*void showMovieFrame(int i)
{	
	loadMovieFrame(i);
	glBindTexture(GL_TEXTURE_2D, texName[1]);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, pmovie->sizeX, pmovie->sizeY, GL_RGB,
		GL_UNSIGNED_BYTE, pmovie->data);
	freeMovieFrame();
}*/


void drawMovie(float x,float y,float z)
{

/*	GLfloat movie[][3]={{0,0,0},{MOVIE_L,0,0},{MOVIE_L,0,MOVIE_H},{0,0,MOVIE_H}};

	glBindTexture(GL_TEXTURE_2D, texName[movie_frame]);
	glPushMatrix(); //used if need to change its position
	glTranslatef(x,y,z);
	/////////////////////
	glTexGeniv(GL_S,GL_TEXTURE_GEN_MODE,linearMap);
	glTexGeniv(GL_T,GL_TEXTURE_GEN_MODE,linearMap);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 1.0); 
	glVertex3fv(movie[0]);
	glTexCoord2f(0.0, 1.0);
	glVertex3fv(movie[1]);
	glTexCoord2f(0.0, 0.0); 
	glVertex3fv(movie[2]);
	glTexCoord2f(1.0, 0.0);
	glVertex3fv(movie[3]);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix(); */
	glPushMatrix();
	glTranslatef(x,y,z);
	drawTexture(MOVIE_L,MOVIE_H,movie_frame);
	glPopMatrix();
	
}


int main(int argc, char** argv)
{	
	///////////////////////////////////////////////
	// ini for both window
	///////////////////////////////////////////////
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DEPTH|GLUT_DOUBLE | GLUT_RGB);
	init();
	//////////////////////////////////////////////
	// first window
	//////////////////////////////////////////////
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (0, 100);
	window1=glutCreateWindow (argv[0]);
	//add code for first window after it is created
	initWindow (1);
	//glClearColor( 0.35f, 0.53f, 0.7f, 1.0f );	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);

	//////////////////////////////////////////////
	// second window
	//////////////////////////////////////////////
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (500, 100);	
	window2=glutCreateWindow ("bird view");
	//add code for second window after it is created
	initWindow (2);
	//glClearColor( 0.35f, 0.53f, 0.7f, 1.0f );
	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape1);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);	
	//glutIdleFunc(idle);
	//////////////////////////////////////////////
	free_texture_file();
	glutMainLoop();
	return 0;
}