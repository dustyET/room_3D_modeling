#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>

#define pi 3.14159
#define BIRD_HEIGHT 20 
typedef enum {
	person_view=1,
		bird_view
}viewer;

//viewer m_view=1;
int window1,window2;
static float mAngle=180;
static float xtrans=8.0,ytrans=3.0,ztrans=0.0;
static float xtarget=0.0,ytarget=0.0,ztarget=0.0;
static float look_length=20,step_length=0.2,angle_step=1.0;//0.5; // could try to vary step size
static float cos_angle=0.0,sine_angle=0.0;

//static float m_position_x=0.0,m_position_y=0.0;
GLfloat no_mat[]={0,0,0,1.0};
int light_on=0;
GLfloat light_position[]={0.0,0.0,30.0,1.0};
GLfloat light_position1[]={0.0,0.0,-1.0,1.0};

GLfloat light_ambient[]={.3,.3,.3,1.0};
GLfloat light_diffuse[]={.6,.6,.6,1.0};
GLfloat light_specular[]={1.0,1.0,1.0,1.0};
GLfloat light_emission[]={1.0,1.0,1.0,1.0};

GLfloat gnd[][3]={{-50,-50,-1.51},{50,-50,-1.51},{50,50,-1.51},{-50,50,-1.51}};
GLfloat room1[][3]={{-10,-10,-1.50},{10,-10,-1.5},{10,10,-1.5},{-10,10,-1.5},
{-10,-10,1.5},{10,-10,1.5},{10,10,1.5},{-10,10,1.5}};
GLfloat room2[][3]={{-10,-10,-1.5},{10,-10,-1.5},{10,10,-1.5},{-10,10,-1.5},
{-10,-10,1.5},{10,-10,1.5},{10,10,1.5},{-10,10,1.5}};

int x_old,y_old;
void init(void)
{		
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_FLAT);
	glEnable(GL_DEPTH_TEST);
	
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT0,GL_AMBIENT,light_ambient);	
	glLightfv(GL_LIGHT0,GL_EMISSION,light_emission);
	//glLightfv(GL_LIGHT0,GL_EMISSION,light_emission);
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);

/*	glLightfv(GL_LIGHT1,GL_DIFFUSE,light_diffuse);
	glLightfv(GL_LIGHT1,GL_AMBIENT,no_mat);	
	glLightfv(GL_LIGHT1,GL_EMISSION,no_mat);
	glLightfv(GL_LIGHT1,GL_POSITION,light_position1);
*/	
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	//glEnable(GL_LIGHT1);
}

void m_Look_at()
{
	glutSetWindow(window1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//gluLookAt (xtrans, ytrans, 0, 0, look_length, ztarget, 0.0, 0.0, 1.0);	
	//gluLookAt (xtrans, ytrans, 0, xtrans+look_length*cos_angle, ytrans+look_length*sine_angle, ztarget, 0.0, 0.0, 1.0);

	gluLookAt (0, 0, 0, look_length,0, ztarget, 0.0, 0.0, 1.0);
	glRotatef(-mAngle,0,0,1);         // rotate camera-- rotate the world inversly, with axis xtrans,ytrans
	glTranslatef(-xtrans,-ytrans,0); // move camera -- move world in the inverse dirction
	
	glutPostWindowRedisplay(window1);

	glutSetWindow(window2);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt (50, 0, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
	glutPostWindowRedisplay(window2);
}

///////////////////////////////////////////////////////
// draw room
//
//
///////////////////////////////////////////////////////


void drawRoom1()
{
	GLfloat mat_ambient_floor[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_cel[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_wall[]={0.25,0.25,0.25,1.0};

	GLfloat mat_diffuse_floor[]={0.2,0.25,0.35,1.0};
	GLfloat mat_diffuse_cel[]={0.3,0.3,0.3,1.0};
	GLfloat mat_diffuse_wall[]={0.5,0.5,0.5,1.0};
	GLfloat mat_specular[]={1.,1.,1.,1.0};
	GLfloat mat_emission[]={1,1,1,1.0};
	
	if(light_on)
	{
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);	
	}
	else
	{
	glLightfv(GL_LIGHT0,GL_DIFFUSE,no_mat);	
	}

	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);
		//floor
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);


	glVertex3fv(room1[0]);
	glVertex3fv(room1[1]);
	glVertex3fv(room1[2]);
	glVertex3fv(room1[3]);
	
	
	//celling
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_cel);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_cel);
/*	if(light_on)
	{
	
	glMaterialfv(GL_FRONT,GL_EMISSION,mat_emission);
	}
	else
	{
		glMaterialfv(GL_FRONT,GL_EMISSION,no_mat);
	}*/
		if(light_on)
	{
	
	glMaterialfv(GL_BACK,GL_EMISSION,mat_emission);
	glMaterialfv(GL_FRONT,GL_EMISSION,no_mat);

	}
	else
	{
		glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
	}

//	if(m_view!=bird_view)
	{
	glVertex3fv(room1[4]);
	glVertex3fv(room1[5]);
	glVertex3fv(room1[6]);
	glVertex3fv(room1[7]);
	}
	//walls	
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_wall);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_wall);
	
	glVertex3fv(room1[0]);
	glVertex3fv(room1[4]);
	glVertex3fv(room1[5]);
	glVertex3fv(room1[1]);
	
	glVertex3fv(room1[2]);
	glVertex3fv(room1[6]);
	glVertex3fv(room1[7]);
	glVertex3fv(room1[3]);
	
	
	glVertex3fv(room1[2]);
	glVertex3fv(room1[6]);
	glVertex3fv(room1[5]);
	glVertex3fv(room1[1]);
	
	
	glVertex3fv(room1[0]);
	glVertex3fv(room1[4]);
	glVertex3fv(room1[7]);
	glVertex3fv(room1[3]);
	
	glEnd();
}

void drawRoom2()
{
	GLfloat mat_ambient_floor[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_cel[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_wall[]={0.25,0.25,0.25,1.0};

	GLfloat mat_diffuse_floor[]={0.2,0.25,0.35,1.0};
	GLfloat mat_diffuse_cel[]={0.3,0.3,0.3,1.0};
	GLfloat mat_diffuse_wall[]={0.5,0.5,0.5,1.0};
	GLfloat mat_specular[]={1.,1.,1.,1.0};
	GLfloat mat_emission[]={1,1,1,1.0};
	
	if(light_on)
	{
	glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);	
	}
	else
	{
	glLightfv(GL_LIGHT0,GL_DIFFUSE,no_mat);	
	}

	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,no_mat);
		//floor
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);


	glVertex3fv(room2[0]);
	glVertex3fv(room2[1]);
	glVertex3fv(room2[2]);
	glVertex3fv(room2[3]);
	
	
	//celling
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_cel);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_cel);
	if(light_on)
	{
	
	glMaterialfv(GL_BACK,GL_EMISSION,mat_emission);
	glMaterialfv(GL_FRONT,GL_EMISSION,no_mat);

	}
	else
	{
		glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
	}

	glVertex3fv(room2[4]);
	glVertex3fv(room2[5]);
	glVertex3fv(room2[6]);
	glVertex3fv(room2[7]);
	
	//walls	
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);	
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_wall);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_wall);
	
	glVertex3fv(room2[0]);
	glVertex3fv(room2[4]);
	glVertex3fv(room2[5]);
	glVertex3fv(room2[1]);
	
	glVertex3fv(room2[2]);
	glVertex3fv(room2[6]);
	glVertex3fv(room2[7]);
	glVertex3fv(room2[3]);
	
	
	glVertex3fv(room2[2]);
	glVertex3fv(room2[6]);
	glVertex3fv(room2[5]);
	glVertex3fv(room2[1]);
	
	
	glVertex3fv(room2[0]);
	glVertex3fv(room2[4]);
	glVertex3fv(room2[7]);
	glVertex3fv(room2[3]);
	
	glEnd();
}

  void drawGround()
  {
	  GLfloat mat_ambient_floor[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_cel[]={0.2,0.2,0.2,1.0};
	GLfloat mat_ambient_wall[]={0.25,0.25,0.25,1.0};

	GLfloat mat_diffuse_floor[]={0.2,0.25,0.35,1.0};
	GLfloat mat_diffuse_cel[]={0.3,0.3,0.3,1.0};
	GLfloat mat_diffuse_wall[]={0.5,0.5,0.5,1.0};
	GLfloat mat_specular[]={1.,1.,1.,1.0};
	GLfloat mat_emission[]={1,1,1,1.0};

	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);

	glBegin(GL_QUADS);
	glVertex3fv(gnd[0]);
	glVertex3fv(gnd[1]);
	glVertex3fv(gnd[2]);
	glVertex3fv(gnd[3]);
	glEnd();
  }

  
  void drawPerson()
  {	 	  
	  GLfloat mat_ambient_floor[]={0.2,0.2,0.2,1.0};
	  GLfloat mat_ambient_cel[]={0.2,0.2,0.2,1.0};
	  GLfloat mat_ambient_wall[]={0.25,0.25,0.25,1.0};
	  
	  GLfloat mat_diffuse_floor[]={0.2,0.25,0.35,1.0};
	  GLfloat mat_diffuse_cel[]={0.3,0.3,0.3,1.0};
	  GLfloat mat_diffuse_wall[]={0.5,0.5,0.5,1.0};
	  GLfloat mat_specular[]={1.,1.,1.,1.0};
	  GLfloat mat_emission[]={1,1,1,1.0};
	  
	  int i;
	  int w=glutGetWindow();
	  glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient_floor);
	  glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse_floor);
	  glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,mat_emission);
	  if(w==window1)
	  {		
		  glutSetWindow(window2);
	  }	  
	  //////////////////////////////////
	  //  debug version
	  //////////////////////////////////	  
	 
	  glMatrixMode(GL_MODELVIEW);
	  glPushMatrix();
	  glLoadIdentity();
	  gluLookAt (50, 0, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
	  glTranslatef(xtrans,ytrans,0);
	  
	  glRotatef(mAngle,0,0,1); // rotate the direction of the person face to
	 
	  
	  {
		  GLfloat person[][3]={{0,0,-1.5},{0,0,-1.5},{0,0,-1.5}};//,{0,0,-1.5},{0,0,-1.5},{0,0,-1.5},{0,0,-1.5}};
		  i=1;
		  person[0][0]=-0.5;
		  person[1][0]=0.5;
		  person[2][0]=-0.5;
		  //person[3][0]=0;
		  
		  person[0][1]=i;
		  person[1][1]=0;
		  person[2][1]=-i;
		  //person[3][1]=-i;
		  
		  //glBegin(GL_QUADS);
		  glBegin(GL_LINE_LOOP);
		  glVertex3fv(person[0]);
		  glVertex3fv(person[1]);
		  glVertex3fv(person[2]);
		  //glVertex3fv(person[2]);
		  glEnd();
	  }
		
	  //	glutWireCone(1,1.5,20,20); //seems glut lib function has changed the lighting effect
	  /////////////////////////////////////////////
	  //  maybe I should draw a 3D person here
	  /////////////////////////////////////////////
	  // to add code here...


	  /////////////////////////////////////////////
	  glPopMatrix();
	  
	  if(w==window1)
	  {		
		  glutSetWindow(window1);
	  }
	  glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,no_mat);
  }
///////////////////////////////////////////////////////
// display the world, change with viewpoint
//
//
///////////////////////////////////////////////////////
void display(void)
{	
	GLfloat mat_ambient[]={0.2,0.2,0.2,1.0};
	GLfloat mat_diffuse[]={0.5,0.5,0.5,1.0};
	GLfloat mat_specular[]={1.,1.,1.,1.0};
	GLfloat mat_emission[]={1,1,1,1.0};
	
	glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	glShadeModel(GL_FLAT);
    
	drawRoom1();

	glPushMatrix();
	glTranslatef(20,0,0);
	drawRoom2();
	glPopMatrix();

	drawGround();
	
	drawPerson();

	glutSwapBuffers();
	
}


void reshape (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1, 30.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	//gluLookAt (xtrans+3, ytrans, ztrans, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
	//gluLookAt (xtrans, ytrans, 0, xtarget, ytarget, ztarget, 0.0, 0.0, 1.0);
	gluLookAt (xtrans, ytrans, 0, xtrans+look_length*cos_angle, ytrans+look_length*sine_angle, ztarget, 0.0, 0.0, 1.0);

}

void reshape1 (int w, int h)
{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1, 100.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt (50, 0, ztrans+BIRD_HEIGHT, 0, 0, 0, 0.0, 0.0, 1.0);
}

/* ARGSUSED1 */
void keyboard (unsigned char key, int x, int y)
{	

	switch (key) {
	case 'o':
		light_on=1;
		m_Look_at();
		break;
	case 'O':
		light_on=0;
		m_Look_at();		
		break;
		/*
	case 'v':
		if(m_view==person_view)
		{
			m_view=bird_view;
		}else
		{
			m_view=person_view;
		}
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();		
		m_Look_at();
		glutPostWindowRedisplay(window1);
		glutPostWindowRedisplay(window2);
		break;
		*/
	case 'f': //forward
		//xtrans+=0.2;
		xtrans+=step_length*cos_angle;
		ytrans+=step_length*sine_angle;
		m_Look_at();
		break;
	case 'b': //backward
		xtrans-=step_length*cos_angle;
		ytrans-=step_length*sine_angle;
		m_Look_at();
		break;
	case 'l': //left
		xtrans-=step_length*sine_angle;
		ytrans+=step_length*cos_angle;
		m_Look_at();
		break;
	case 'r': //right
		xtrans+=step_length*sine_angle;
		ytrans-=step_length*cos_angle;
		m_Look_at();
		break;
	case 'u': //up
		ztrans+=0.2;
		m_Look_at();
		break;
	case 'd': //down
		ztrans-=0.2;
		m_Look_at();
		break;

//////////////////////////////////////////////
		// try to add angle control
/*		case 'F': //forward
		xtarget+=step_szie;//0.2;
		m_Look_at();
		break;
	case 'B': //backward
		xtarget-=step_size;//0.2;
		m_Look_at();
		break;
		*/
	case 'L': //left
		//ytarget+=0.2;
		mAngle+=angle_step;//0.2;
		m_Look_at();
		break;
	case 'R': //right
		mAngle-=angle_step;//0.2;
		m_Look_at();
		break;
	case 'U': //up
		ztarget+=0.2;
		m_Look_at();
		break;
	case 'D': //down
		ztarget-=0.2;
		m_Look_at();
		break;
//////////////////////////////////////////////
		
	case 27:
		exit(0);
		break;
	default:
		break;
	}
	if(mAngle>=360) mAngle=mAngle-360;
	if(mAngle<0) mAngle+=360;
	cos_angle=cos(mAngle/180.0*pi); // the paraameter should be in arc, not degree
	sine_angle=sin(mAngle/180.0*pi);
	
}
void idle()
{
	
}

void mouse(int btn, int state, int x, int y)
{
	
	/* mouse callback, selects an axis about which to rotate */
	int dx,dy;
	cos_angle=cos(mAngle/180.0*pi);
	sine_angle=sin(mAngle/180.0*pi);
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{

		x_old=x;
		y_old=y;
	}
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		dx=x-x_old;
		dy=y-y_old;

		//debug only
		//light_position[0]+=dx/20;
		//light_position[1]+=(y-y_old)/20;
		//glLightfv(GL_LIGHT0,GL_POSITION,light_position);
		
		
		ytrans+=dx/100.0;
		xtrans+=dy/100.0;
		m_Look_at();
	
	}
	
	//if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) axis = 1;
	//if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) axis = 2;

}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DEPTH|GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (0, 100);
	window1=glutCreateWindow (argv[0]);
	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);

	glutInitWindowSize (500, 500);
	glutInitWindowPosition (500, 100);
	window2=glutCreateWindow ("bird view");
	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape1);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);

	glutMainLoop();
	return 0;
}